# Cayetana English v1.2

Aplicación Android offline para estudiar vocabulario Cambridge Pre A1 Starters Digital.

Novedades v1.2: identidad visual, icono personalizado, estadísticas, reinicio de progreso, conteo por palabra, tres juegos (significado, completar oración, elegir imagen), oraciones infantiles mejoradas y repaso adaptativo.


## v1.3
- Reinicio total con confirmación dentro de la app.
- Fondo decorativo pastel.
- Icono circular sin esquinas blancas.
- Pestaña Actividad con historial persistente de tandas, juegos y lecciones.
