# Cayetana English v1.2

Aplicación Android offline para estudiar vocabulario Cambridge Pre A1 Starters Digital.

Novedades v1.2: identidad visual, icono personalizado, estadísticas, reinicio de progreso, conteo por palabra, tres juegos (significado, completar oración, elegir imagen), oraciones infantiles mejoradas y repaso adaptativo.
