# Starters de Cayetana 1.1

App Android offline para practicar el vocabulario de Cambridge Pre A1 Starters Digital.

Mejoras 1.1:
- Juego por bloques de 20 palabras.
- Respuesta incorrecta en rojo con doble destello.
- Pista de audio tras dos fallos en una misma palabra.
- Respuesta correcta en verde, fuegos artificiales y sonido sutil.
- Registro persistente de aciertos y errores.
- Repetición automática de palabras falladas hasta responderlas sin error.
- Pestaña Lecciones por temas y por letra.
- Navegación hacia atrás/adelante y "Más tarde" en Estudiar.
- Celebración animada al completar juegos y lecciones.
