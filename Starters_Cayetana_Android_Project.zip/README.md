# Starters Cayetana Android

App Android offline para estudiar Cambridge Pre A1 Starters Digital.

## Compilar APK en GitHub

1. Sube todo el contenido de este proyecto al repositorio.
2. Abre **Actions**.
3. Entra a **Build Android APK**.
4. Pulsa **Run workflow**.
5. Cuando termine, abre la ejecución y descarga el artefacto **Starters-Cayetana-APK**.
6. Dentro del ZIP descargado estará `app-debug.apk`.

También se compila automáticamente con cada push a `main`.
